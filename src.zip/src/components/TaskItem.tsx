import {View, Text, TouchableOpacity, StyleSheet, TextInput} from "react-native"

export function TaskItem(){
    return(
        <View>
            <TextInput
                placeholder="Item da Tarefa"
            />
            <View>
                {/*Botão Editar e Salvar*/}
                <TouchableOpacity>
                    <Text>V</Text>
                </TouchableOpacity>
                {/*Botão Excluir */}
                <TouchableOpacity>
                    <Text>X</Text>
                </TouchableOpacity>
            </View>
        </View>
    )
}

const styles = StyleSheet.create({
    taskCard:{
        backgroundColor: "#fff",
        padding: 15,
        borderRadius: 8,
        flexDirection: "row",
        justifyContent: "space-between",
        alignItems: "center",
        marginBottom: 10,
        borderWidth: 1,
        borderColor: "#e0e0e0"
    },
    tasKText:{
        fontSize: 16,
        color: "#333",
        flex: 1,
        marginRight: 10
    },
    editInput:{
        flex: 1,
        fontSize: 16,
        color: "#333",
        borderBottomWidth: 1,
        borderBottomColor: "#007bff",
        padding: 0,
        marginRight: 10,
    },
    actionContainer:{
        flexDirection: "row",
    },
    actionButton:{
        width: 32,
        height: 32,
        borderRadius: 16,
        justifyContent: "center",
        alignItems: "center",
        marginLeft: 8,
    },
    editButton:{
        backgroundColor: "#ff9500",
    },
    saveButton:{
        backgroundColor: "#34c759",
    },
        deleteButt:{
            backgroundColor: "#ff3b30",
        },
        buttonText:{
            color:"#fff",
            fontWeight: "bold"
        }
})